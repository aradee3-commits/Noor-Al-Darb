package org.nooraldarb.app

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONObject
import java.util.concurrent.Executor

private val DeepGreen = Color(0xFF123C32)
private val Gold = Color(0xFFD6B66A)

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try { controller = controllerFuture?.get() } catch (_: Exception) { controller = null }
        }, Executor { command -> runOnUiThread(command) })
        val initialEpisodes = ArchiveCatalog.loadCached(this).ifEmpty { loadEpisodes() }
        setContent {
            var episodes by remember { mutableStateOf(initialEpisodes) }
            var loading by remember { mutableStateOf(false) }
            var message by remember { mutableStateOf("يمكن تحديث الفهرس من أرشيف الإنترنت") }
            NoorHome(episodes, loading, message,
                onRefresh = {
                    if (!loading) {
                        loading = true
                        message = "جارٍ جلب قائمة الحلقات من الأرشيف..."
                        lifecycleScope.launch {
                            try {
                                episodes = ArchiveCatalog.refresh(this@MainActivity)
                                message = "تم تحديث الفهرس: ${episodes.size} ملفاً صوتياً"
                            } catch (e: Exception) {
                                message = "تعذر التحديث: ${e.localizedMessage ?: "تحقق من اتصال الإنترنت"}"
                            } finally { loading = false }
                        }
                    }
                }, onPlay = { episode ->
            controller?.apply {
                setMediaItem(MediaItem.Builder().setMediaId(episode.id).setUri(episode.audioUrl)
                    .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(episode.title).build()).build())
                prepare()
                play()
            }
        }, onToggle = { controller?.let { if (it.isPlaying) it.pause() else it.play() } })
        }
    }

    private fun loadEpisodes(): List<Episode> = try {
        val json = assets.open("episodes.json").bufferedReader().use { it.readText() }
        val array = JSONObject(json).getJSONArray("episodes")
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            Episode(item.getString("id"), item.getString("title"), item.getString("audioUrl"), item.getInt("order"))
        }
    } catch (_: Exception) { emptyList() }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}

@Composable
private fun NoorHome(episodes: List<Episode>, loading: Boolean, message: String, onRefresh: () -> Unit, onPlay: (Episode) -> Unit, onToggle: () -> Unit) {
    var selected by remember(episodes) { mutableStateOf(episodes.firstOrNull()) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = DeepGreen, surface = DeepGreen)) {
        Column(Modifier.fillMaxSize().background(DeepGreen).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(22.dp))
            Text("نور على الدرب", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("فضيلة الشيخ صالح بن محمد اللحيدان رحمه الله", color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1D5144)), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("الحلقة المختارة", color = Gold)
                    Text(selected?.title ?: "سيظهر فهرس الحلقات هنا بعد تحميله", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onToggle, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepGreen)) { Text("تشغيل / إيقاف") }
                    Text("يعمل التشغيل عبر خدمة صوتية بالخلفية عند توفر الاتصال", color = Color.LightGray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Button(onClick = onRefresh, enabled = !loading, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepGreen)) {
                    Text(if (loading) "جارٍ التحديث..." else "تحديث الفهرس")
                }
                Text("فهرس الحلقات (${episodes.size})", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Text(message, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
            if (episodes.isEmpty()) Text("لم يتم تحميل الفهرس بعد", color = Color.White)
            LazyColumn(Modifier.fillMaxWidth()) {
                items(episodes, key = { it.id }) { ep ->
                    TextButton(onClick = { selected = ep; onPlay(ep) }, modifier = Modifier.fillMaxWidth()) {
                        Text("${ep.order}.  ${ep.title}", color = Color.White, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}
