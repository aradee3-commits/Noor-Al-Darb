package org.nooraldarb.app

data class Episode(
    val id: String,
    val title: String,
    val audioUrl: String,
    val order: Int
)
