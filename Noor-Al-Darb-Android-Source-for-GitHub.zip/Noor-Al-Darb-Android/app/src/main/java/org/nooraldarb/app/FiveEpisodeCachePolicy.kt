package org.nooraldarb.app

/** Keeps the current episode and the next four entries in catalog order. */
object FiveEpisodeCachePolicy {
    fun retainedIds(catalog: List<Episode>, currentId: String): Set<String> {
        val index = catalog.indexOfFirst { it.id == currentId }
        if (index < 0) return emptySet()
        return catalog.drop(index).take(5).mapTo(linkedSetOf()) { it.id }
    }
}
