package org.nooraldarb.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Downloads the Internet Archive metadata and atomically caches its VBR MP3 catalog. */
object ArchiveCatalog {
    private const val IDENTIFIER = "0966_20220210"
    private const val METADATA_URL = "https://archive.org/metadata/$IDENTIFIER"

    suspend fun refresh(context: Context): List<Episode> = withContext(Dispatchers.IO) {
        val connection = (URL(METADATA_URL).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 60_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "NoorAlDarbAndroid/1.0")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("تعذر الوصول إلى أرشيف الإنترنت (HTTP $code)")
            }
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            val files = root.optJSONArray("files")
                ?: throw IllegalStateException("استجاب الأرشيف، لكن قائمة الملفات غير موجودة")

            val episodes = ArrayList<Episode>()
            val seen = HashSet<String>()
            for (i in 0 until files.length()) {
                val file = files.optJSONObject(i) ?: continue
                val name = file.optString("name").trim()
                val format = file.optString("format").trim()
                // The archive identifies the desired originals as VBR MP3.
                // Do not require the optional `source` field: IA metadata may
                // omit it on some records even when format/name are valid.
                if (!name.endsWith(".mp3", ignoreCase = true)) continue
                if (!format.equals("VBR MP3", ignoreCase = true)) continue
                if (name.startsWith("__ia_thumb", ignoreCase = true)) continue
                if (!seen.add(name)) continue

                val encodedPath = name.split('/').joinToString("/") { Uri.encode(it) }
                val audioUrl = "https://archive.org/download/$IDENTIFIER/$encodedPath"
                val title = name.substringAfterLast('/')
                    .let { if (it.endsWith(".mp3", true)) it.dropLast(4) else it }
                    .replace('_', ' ')
                episodes += Episode(name, title, audioUrl, episodes.size + 1)
            }
            if (episodes.isEmpty()) {
                throw IllegalStateException("لم نعثر على ملفات بصيغة VBR MP3؛ لم يتم استبدال الفهرس المحفوظ")
            }

            val jsonEpisodes = JSONArray().apply {
                episodes.forEach { ep ->
                    put(JSONObject()
                        .put("id", ep.id)
                        .put("title", ep.title)
                        .put("audioUrl", ep.audioUrl)
                        .put("order", ep.order))
                }
            }
            val catalog = JSONObject()
                .put("source", "https://archive.org/details/$IDENTIFIER")
                .put("updatedAt", System.currentTimeMillis())
                .put("count", episodes.size)
                .put("episodes", jsonEpisodes)

            // Atomic replacement prevents a failed refresh from corrupting the old catalog.
            val target = File(context.filesDir, "episodes.json")
            val temp = File(context.filesDir, "episodes.json.tmp")
            temp.writeText(catalog.toString(), Charsets.UTF_8)
            if (target.exists() && !target.delete()) {
                temp.delete()
                throw IllegalStateException("تعذر تحديث نسخة الفهرس المحفوظة")
            }
            if (!temp.renameTo(target)) {
                temp.delete()
                throw IllegalStateException("تعذر حفظ الفهرس الجديد على الهاتف")
            }
            episodes
        } finally {
            connection.disconnect()
        }
    }

    fun loadCached(context: Context): List<Episode> = try {
        val file = File(context.filesDir, "episodes.json")
        if (!file.exists()) emptyList() else {
            val array = JSONObject(file.readText(Charsets.UTF_8)).getJSONArray("episodes")
            (0 until array.length()).map { i ->
                val item = array.getJSONObject(i)
                Episode(item.getString("id"), item.getString("title"), item.getString("audioUrl"), item.getInt("order"))
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}
