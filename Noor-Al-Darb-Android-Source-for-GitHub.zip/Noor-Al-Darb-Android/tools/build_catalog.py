#!/usr/bin/env python3
"""Build episodes.json from the official Internet Archive metadata endpoint.

Usage:
  python tools/build_catalog.py
  python tools/build_catalog.py --input metadata.json  # offline validation/import
"""
import argparse
import json
import urllib.request
from pathlib import Path
from urllib.parse import quote

IDENTIFIER = "0966_20220210"
API = f"https://archive.org/metadata/{IDENTIFIER}"
OUT = Path(__file__).resolve().parents[1] / "app/src/main/assets/episodes.json"


def make_catalog(metadata):
    files = metadata.get("files")
    if not isinstance(files, list):
        raise ValueError("Metadata JSON does not contain a files array")

    episodes, seen = [], set()
    for item in files:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name", "")).strip()
        fmt = str(item.get("format", "")).strip()
        if not name.lower().endswith(".mp3") or fmt.casefold() != "vbr mp3":
            continue
        if name.startswith("__ia_thumb") or name in seen:
            continue
        seen.add(name)
        encoded = "/".join(quote(part, safe="") for part in name.split("/"))
        title = Path(name).stem.replace("_", " ")
        episodes.append({
            "id": name,
            "title": title,
            "audioUrl": f"https://archive.org/download/{IDENTIFIER}/{encoded}",
            "order": len(episodes) + 1,
        })

    if not episodes:
        raise ValueError("No VBR MP3 files found; catalog was not written")
    return {
        "source": f"https://archive.org/details/{IDENTIFIER}",
        "count": len(episodes),
        "episodes": episodes,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, help="Use an existing metadata JSON file instead of the network")
    args = parser.parse_args()

    if args.input:
        metadata = json.loads(args.input.read_text(encoding="utf-8"))
    else:
        request = urllib.request.Request(API, headers={"Accept": "application/json", "User-Agent": "NoorAlDarbCatalog/1.0"})
        with urllib.request.urlopen(request, timeout=60) as response:
            metadata = json.load(response)

    catalog = make_catalog(metadata)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    temp = OUT.with_suffix(".json.tmp")
    temp.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(OUT)
    print(f"تم إنشاء الفهرس: {catalog['count']} ملف VBR MP3")
    print(f"الملف: {OUT}")


if __name__ == "__main__":
    main()
