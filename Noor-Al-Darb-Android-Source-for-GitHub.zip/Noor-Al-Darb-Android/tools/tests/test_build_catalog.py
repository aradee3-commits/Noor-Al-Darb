import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from build_catalog import make_catalog


class CatalogTests(unittest.TestCase):
    def test_only_vbr_mp3_original_listing_and_direct_urls(self):
        metadata = {"files": [
            {"name": "0001-نور على الدرب.mp3", "format": "VBR MP3"},
            {"name": "0002-second.mp3", "format": "VBR MP3"},
            {"name": "0001-preview.mp3", "format": "MP3"},
            {"name": "cover.jpg", "format": "JPEG"},
            {"name": "0002-second.mp3", "format": "VBR MP3"},
        ]}
        catalog = make_catalog(metadata)
        self.assertEqual(catalog["count"], 2)
        self.assertEqual([x["order"] for x in catalog["episodes"]], [1, 2])
        self.assertIn("%20", catalog["episodes"][0]["audioUrl"])
        self.assertTrue(catalog["episodes"][0]["audioUrl"].endswith(".mp3"))

    def test_empty_result_is_not_accepted(self):
        with self.assertRaises(ValueError):
            make_catalog({"files": [{"name": "cover.jpg", "format": "JPEG"}]})

    def test_missing_files_array_is_not_accepted(self):
        with self.assertRaises(ValueError):
            make_catalog({})


if __name__ == "__main__":
    unittest.main()
